package com.infinito.KYC.dto;

import lombok.Data;

@Data
public class RoleDTO {
    private long id;
    private String name;
}
