package com.infinito.KYC.exception;

public class OurException extends RuntimeException{

    public OurException(String message){
        super(message);
    }
}
