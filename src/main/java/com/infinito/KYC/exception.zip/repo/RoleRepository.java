package com.infinito.KYC.repo;

import com.infinito.KYC.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Long> {

}
